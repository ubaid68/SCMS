-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Nov 08, 2012 at 05:20 PM
-- Server version: 5.5.8
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `scmsdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `customer`
--

CREATE TABLE IF NOT EXISTS `customer` (
  `cu_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'customer id',
  `cu_name` varchar(50) NOT NULL COMMENT 'customer name',
  `cu_desp` varchar(200) NOT NULL COMMENT 'customer description',
  PRIMARY KEY (`cu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;

--
-- Dumping data for table `customer`
--

INSERT INTO `customer` (`cu_id`, `cu_name`, `cu_desp`) VALUES
(2, 'Mr ahmed ali', 'Mr ahmed ali fom ali associates'),
(3, 'Mr Sheraz', 'Mr Sheraz ali fom Sheraz associates'),
(4, 'Mr hamdani ', 'hamdani group of companies'),
(6, 'Mr shahiad ali', 'karera technologies'),
(7, 'furqan ali', 'furqanali');

-- --------------------------------------------------------

--
-- Table structure for table `defective_material`
--

CREATE TABLE IF NOT EXISTS `defective_material` (
  `dm_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'return defective material as primary key',
  `login_id` int(11) NOT NULL COMMENT 'login_id as foreign key',
  `rm_id` int(11) NOT NULL COMMENT 'raw material id as foreign key',
  `dm_quantity` int(11) NOT NULL COMMENT 'return defective material quantity',
  `dm_date` date NOT NULL COMMENT 'return defective material date',
  PRIMARY KEY (`dm_id`),
  KEY `FK_rawmaterial_id` (`rm_id`),
  KEY `FK_loggedin_id` (`login_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `defective_material`
--


-- --------------------------------------------------------

--
-- Table structure for table `employee`
--

CREATE TABLE IF NOT EXISTS `employee` (
  `login_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'login id as primary key',
  `et_id` int(11) NOT NULL COMMENT 'employee typeid as foreign key',
  `user_name` varchar(50) NOT NULL COMMENT 'username by which user can login',
  `password` varchar(50) NOT NULL COMMENT 'password',
  `u_fname` varchar(50) NOT NULL COMMENT 'first name',
  `u_lname` varchar(50) NOT NULL COMMENT 'last name',
  PRIMARY KEY (`login_id`),
  KEY `fk_et_id` (`et_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=22 ;

--
-- Dumping data for table `employee`
--

INSERT INTO `employee` (`login_id`, `et_id`, `user_name`, `password`, `u_fname`, `u_lname`) VALUES
(10, 6, 'admin', 'admin', 'ubaid', 'rehman'),
(11, 7, 'amir', 'amir', 'amir', 'abbasi'),
(12, 6, 'ahmed', 'ahmed123', 'ahmed', 'saeed'),
(13, 6, 'masoom', 'masoom', 'masoom1', 'ali'),
(14, 7, 'abc', '123456', 'rakshanda', 'rakshanda'),
(15, 6, 'amir', 'kkkk', 'kkk', 'sss'),
(16, 7, 'ahmed', 'ahemd', 'ahmed', 'ahmed'),
(17, 13, 'cvx', 'jh', 'jhkj', 'bjbk'),
(18, 7, 'm', 'm', 'm', 'm'),
(19, 13, 'ali', '123456', 'ali', 'rehman'),
(20, 18, 'new', 'newnew', 'new', 'new'),
(21, 22, 'admin', '123456', 'ubaid', 'rehman');

-- --------------------------------------------------------

--
-- Table structure for table `employee_type`
--

CREATE TABLE IF NOT EXISTS `employee_type` (
  `et_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'employee typeid ',
  `et_name` varchar(20) NOT NULL COMMENT 'employee type name',
  `et_desp` varchar(200) NOT NULL COMMENT 'employee type description',
  PRIMARY KEY (`et_id`),
  UNIQUE KEY `et_name` (`et_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `employee_type`
--

INSERT INTO `employee_type` (`et_id`, `et_name`, `et_desp`) VALUES
(6, 'Adsss', 'have all rights'),
(7, 'product manager', 'manages product'),
(13, 'RawMaterial Manager', 'lsvlsdcsm'),
(14, 'Accountant', 'cvxxc'),
(16, 'Accountant sales', 'kjhkj'),
(17, 'bbb', 'jhjk'),
(18, 'Accountant Finance', 'q'),
(19, 'new', 'new23'),
(20, 'szcsa', 'dasda'),
(21, 'admin', 'admin'),
(22, 'administrator', 'admin desp');

-- --------------------------------------------------------

--
-- Table structure for table `factory_material`
--

CREATE TABLE IF NOT EXISTS `factory_material` (
  `sf_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'send material factory primary id',
  `login_id` int(11) NOT NULL COMMENT 'login_id as foreign key',
  `rm_id` int(11) NOT NULL COMMENT 'raw material id as foreign key',
  `sf_quantity` int(11) NOT NULL COMMENT 'send material factory quantity',
  `sf_date` date NOT NULL COMMENT 'send material factory date',
  PRIMARY KEY (`sf_id`),
  KEY `FK_raw_materials_id` (`rm_id`),
  KEY `FK_logedin_id` (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=32 ;

--
-- Dumping data for table `factory_material`
--

INSERT INTO `factory_material` (`sf_id`, `login_id`, `rm_id`, `sf_quantity`, `sf_date`) VALUES
(2, 10, 1, 0, '2012-11-19'),
(3, 10, 13, 1, '2012-11-19'),
(4, 10, 5, 1, '2012-11-19'),
(5, 10, 5, 1, '2012-11-19'),
(6, 10, 5, 22, '2012-11-02'),
(8, 10, 1, 1, '2012-11-19'),
(9, 10, 5, 50, '2012-11-12'),
(10, 10, 5, 50, '2012-11-12'),
(11, 10, 15, 22, '2012-11-13'),
(12, 10, 15, 22, '2012-11-12'),
(13, 10, 15, 22, '2012-11-19'),
(14, 10, 1, 10, '2012-11-19'),
(15, 10, 1, 1, '2012-11-25'),
(16, 10, 2, 1, '2012-11-20'),
(17, 10, 1, 100, '2012-11-13'),
(18, 10, 1, 100, '2012-11-12'),
(19, 10, 1, 100, '2012-11-19'),
(20, 10, 1, 7, '2012-11-12'),
(21, 10, 5, 50, '2012-11-12'),
(22, 10, 2, 9, '2012-11-12'),
(23, 10, 2, 9, '2012-11-07'),
(24, 10, 5, 25, '2012-11-05'),
(25, 10, 5, 25, '2012-11-05'),
(26, 10, 5, 25, '2012-11-13'),
(27, 10, 5, 2, '2012-11-13'),
(28, 10, 5, 23, '2012-11-12'),
(29, 10, 5, 23, '2012-11-01'),
(30, 10, 5, 23, '2012-11-20'),
(31, 10, 2, 82, '2012-11-20');

-- --------------------------------------------------------

--
-- Table structure for table `finished_product`
--

CREATE TABLE IF NOT EXISTS `finished_product` (
  `fp_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'finished/recieve product primary key',
  `login_id` int(11) NOT NULL COMMENT 'login_id as foreign key',
  `p_id` int(11) NOT NULL COMMENT 'product id as foreign key',
  `fp_quantity` int(11) NOT NULL COMMENT 'finished/recieve product quantity',
  `fp_date` date NOT NULL COMMENT 'finished/recieve date',
  PRIMARY KEY (`fp_id`),
  KEY `FK_products_id` (`p_id`),
  KEY `FK_loginnn_id` (`login_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `finished_product`
--

INSERT INTO `finished_product` (`fp_id`, `login_id`, `p_id`, `fp_quantity`, `fp_date`) VALUES
(1, 10, 1, 100, '2012-11-26'),
(2, 10, 2, 200, '2012-11-07'),
(3, 10, 3, 100, '2012-11-20');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `p_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'product id/serial no',
  `pc_id` int(11) NOT NULL COMMENT 'product category id',
  `p_name` varchar(30) NOT NULL COMMENT 'product name',
  `p_code` varchar(10) NOT NULL COMMENT 'product code',
  `p_price` double NOT NULL COMMENT 'product price',
  `p_quantity` int(11) NOT NULL COMMENT 'product quantity',
  `p_reservelevel` int(11) NOT NULL COMMENT 'product warning level',
  PRIMARY KEY (`p_id`),
  UNIQUE KEY `p_name` (`p_name`),
  UNIQUE KEY `p_code` (`p_code`),
  KEY `product` (`pc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`p_id`, `pc_id`, `p_name`, `p_code`, `p_price`, `p_quantity`, `p_reservelevel`) VALUES
(1, 6, 'marker', 'mz1234', 66, 177, 8),
(2, 10, 'chinese pencil', 'cp101', 87, 256, 7),
(3, 10, 'piano pencil', 'pp134', 1, 144, 44);

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE IF NOT EXISTS `product_category` (
  `pc_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'product category id',
  `pc_name` varchar(50) NOT NULL COMMENT 'product category name',
  `pc_qmeasures` varchar(20) NOT NULL COMMENT 'product category meansures',
  `pc_description` varchar(200) NOT NULL COMMENT 'product category description',
  PRIMARY KEY (`pc_id`),
  UNIQUE KEY `pc_name` (`pc_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `product_category`
--

INSERT INTO `product_category` (`pc_id`, `pc_name`, `pc_qmeasures`, `pc_description`) VALUES
(6, 'product category test', 'packs', 'df'),
(10, 'pencils', 'packets', 'pencils category'),
(12, 'hdsfhsd dfsdj', 'fdf', ' dffdf dfdf'),
(13, 'rrr', 'ggg', 'rerre');

-- --------------------------------------------------------

--
-- Table structure for table `purchaser_type`
--

CREATE TABLE IF NOT EXISTS `purchaser_type` (
  `purt_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'purchaser typess id',
  `purt_name` varchar(20) NOT NULL COMMENT 'purchaser typess name',
  `purt_desp` varchar(200) NOT NULL COMMENT 'purchaser type description',
  PRIMARY KEY (`purt_id`),
  UNIQUE KEY `purt_name` (`purt_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `purchaser_type`
--

INSERT INTO `purchaser_type` (`purt_id`, `purt_name`, `purt_desp`) VALUES
(5, 'wholesale', 'wholesale'),
(6, 'Retail', 'Retail'),
(7, 'Govermental', 'Govermental'),
(8, 'Private', 'Private'),
(9, 'Semi Govermental', 'Semi Govermental'),
(10, 'testtype', '4234'),
(11, 'aaa', 'aaaaa');

-- --------------------------------------------------------

--
-- Table structure for table `rawmaterial`
--

CREATE TABLE IF NOT EXISTS `rawmaterial` (
  `rm_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'raw material id',
  `rmc_id` int(11) NOT NULL COMMENT 'raw material category id as foreign key',
  `rm_name` varchar(30) NOT NULL COMMENT 'raw material name',
  `rm_code` varchar(10) NOT NULL COMMENT 'raw material code',
  `rmp_unit` double NOT NULL COMMENT 'raw material unit price',
  `rm_quantity` int(11) NOT NULL COMMENT 'raw material quantity',
  `rm_reservelevel` int(11) NOT NULL COMMENT 'raw material reserve level',
  PRIMARY KEY (`rm_id`),
  UNIQUE KEY `rm_code` (`rm_code`),
  KEY `fk_rmc_id` (`rmc_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `rawmaterial`
--

INSERT INTO `rawmaterial` (`rm_id`, `rmc_id`, `rm_name`, `rm_code`, `rmp_unit`, `rm_quantity`, `rm_reservelevel`) VALUES
(1, 3, 'rawma ma', 'jsn5', 33, 25, 334),
(2, 4, 'raw material', 'rm102', 50, 81, 120),
(5, 3, 'raw materiallll', 'rm103', 33, 0, 120),
(13, 4, 'sodu', 'sr1021', 0, 0, 0),
(14, 4, 'qqwq eqweqw', 'uuu123 33', 33, 12, 44),
(15, 3, 'bzdncknjacdf dfsd', '3232', 33, 222, 22),
(16, 4, 'aaa', 'aaa', 33, 100, 120),
(17, 3, 'vv', 'vv', 33, 7, 120),
(18, 4, 'ree', 'eree', 1, 1, 1),
(19, 3, 'ewewewewe', 'uyuy', 1, 1, 1),
(20, 3, 'das', 'dsa', 1, 1, 1),
(21, 4, 'mjh', 'klnhjkl', 1, 1, 1),
(22, 3, 'asa asa', 'asa', 24, 44, 55),
(23, 4, 'fdsds', 'ewfw', 66, 55, 33),
(24, 4, 'JHGH', 'HJGJH', 88, 88, 8888);

-- --------------------------------------------------------

--
-- Table structure for table `rawmaterial_category`
--

CREATE TABLE IF NOT EXISTS `rawmaterial_category` (
  `rmc_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'raw material category id',
  `rmc_name` varchar(50) NOT NULL COMMENT 'rmc name',
  `rmc_qmeasures` varchar(20) NOT NULL COMMENT 'raw material quantity  measures',
  `rmc_description` varchar(200) NOT NULL COMMENT 'rawmaterial desp',
  PRIMARY KEY (`rmc_id`),
  UNIQUE KEY `rmc_name` (`rmc_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `rawmaterial_category`
--

INSERT INTO `rawmaterial_category` (`rmc_id`, `rmc_name`, `rmc_qmeasures`, `rmc_description`) VALUES
(3, 'woooden', 'kgs', 'vcbv'),
(4, 'dop oil', 'liters', 'DOP OIL FOR PAINTING'),
(9, 'a', 'a', 'a'),
(10, 'ttt', 't', 't'),
(11, 'thinnew', 'ww', 'eenhhjj'),
(12, 'yyy', 'yy', 'yyyyy');

-- --------------------------------------------------------

--
-- Table structure for table `sale_pr`
--

CREATE TABLE IF NOT EXISTS `sale_pr` (
  `sp_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'sale product id as primary key',
  `p_id` int(11) NOT NULL COMMENT 'product id as foreign key',
  `login_id` int(11) NOT NULL COMMENT 'login_id as foreign key',
  `cu_id` int(11) NOT NULL COMMENT 'customer id as foreign key',
  `st_id` int(11) NOT NULL COMMENT 'sale type id as foreign key',
  `purt_id` int(11) NOT NULL COMMENT 'purchaser typess id as foreign key',
  `sp_date` text NOT NULL COMMENT 'sale product date',
  `sp_unit` double NOT NULL COMMENT 'sale product unit price',
  `sp_quantity` int(11) NOT NULL COMMENT 'sale product quantity',
  `sp_discount` int(11) NOT NULL COMMENT 'sale product discount',
  PRIMARY KEY (`sp_id`),
  KEY `fk_p_id` (`p_id`),
  KEY `fk_login_id` (`login_id`),
  KEY `fk_st1_id` (`st_id`),
  KEY `fk_purt_id` (`purt_id`),
  KEY `FK_customer_id` (`cu_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Dumping data for table `sale_pr`
--

INSERT INTO `sale_pr` (`sp_id`, `p_id`, `login_id`, `cu_id`, `st_id`, `purt_id`, `sp_date`, `sp_unit`, `sp_quantity`, `sp_discount`) VALUES
(1, 1, 10, 2, 11, 5, '2012-11-20', 20, 200, 2),
(2, 2, 10, 7, 16, 7, '2012-11-20', 2, 25, 3),
(3, 2, 10, 6, 11, 5, '2012-10-24', 66, 55, 77);

-- --------------------------------------------------------

--
-- Table structure for table `sale_rm`
--

CREATE TABLE IF NOT EXISTS `sale_rm` (
  `srm_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'sale raw material',
  `cu_id` int(11) NOT NULL COMMENT 'customer  id as foreign key',
  `login_id` int(11) NOT NULL COMMENT 'login id as foreign key',
  `rm_id` int(11) NOT NULL COMMENT 'raw material id as foreign key',
  `st_id` int(11) NOT NULL COMMENT 'raw material id as foreign keys',
  `purt_id` int(11) NOT NULL COMMENT 'purchaser typess id as foreign key',
  `srm_date` datetime NOT NULL COMMENT 'sale raw material date ',
  `srmp_unit` double NOT NULL COMMENT 'sale raw material unit price',
  `srm_quantity` int(11) NOT NULL COMMENT 'sale raw material quantity',
  `srm_discount` int(11) NOT NULL COMMENT 'sale raw material discount',
  PRIMARY KEY (`srm_id`),
  KEY `fk_cus_id` (`cu_id`),
  KEY `fk_loginn_id` (`login_id`),
  KEY `fk_rm_id` (`rm_id`),
  KEY `fk_st2_id` (`st_id`),
  KEY `fk_purtt_id` (`purt_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `sale_rm`
--


-- --------------------------------------------------------

--
-- Table structure for table `sale_type`
--

CREATE TABLE IF NOT EXISTS `sale_type` (
  `st_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'sale type id  as primary key',
  `st_name` varchar(20) NOT NULL COMMENT 'saletype name',
  `st_description` varchar(200) NOT NULL COMMENT 'saletype despriction',
  PRIMARY KEY (`st_id`),
  UNIQUE KEY `st_name` (`st_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=30 ;

--
-- Dumping data for table `sale_type`
--

INSERT INTO `sale_type` (`st_id`, `st_name`, `st_description`) VALUES
(11, 'send sample', 'send sample'),
(16, 'sale', 'rrsefse grgter'),
(17, 'saleeee', 'dczsdczxc'),
(18, 'hjg', ',n,mn'),
(19, 'hhh', 'rrsefse grgter'),
(22, 'aaaaaaaaaaa', 'klnjlk'),
(23, 'newsuccess', 'klfjdskfsld'),
(25, 'czdsfs', 'xzcz'),
(26, 'czxczc', 'xzcx xczz'),
(27, 'asa asa', 'asa'),
(29, 'dont know', 'hewllo');

-- --------------------------------------------------------

--
-- Table structure for table `supplier`
--

CREATE TABLE IF NOT EXISTS `supplier` (
  `s_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'supplier id ',
  `supplier_name` varchar(50) NOT NULL COMMENT 'supplier company name',
  `s_person` varchar(50) NOT NULL COMMENT 'concern supplier person',
  `s_phone` varchar(20) NOT NULL COMMENT 'supplier contact number',
  `s_address` varchar(200) NOT NULL COMMENT 'supplier address',
  PRIMARY KEY (`s_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=13 ;

--
-- Dumping data for table `supplier`
--

INSERT INTO `supplier` (`s_id`, `supplier_name`, `s_person`, `s_phone`, `s_address`) VALUES
(9, 'yii hang', 'kanfu', '1234567', 'shanghai china'),
(10, 'mounti cristo', 'Mr mounti', '122333333333', 'sadfs'),
(11, 'rasheed sons', 'Mr rashid', '123456789', 'muzaffarghar'),
(12, 'AAQS enterprises', 'Mr aaquib', '1234567', 'sailkot daska');

-- --------------------------------------------------------

--
-- Table structure for table `supplies`
--

CREATE TABLE IF NOT EXISTS `supplies` (
  `supplies_id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'supplies no',
  `s_id` int(11) NOT NULL COMMENT 'supplier id as foreign key',
  `rm_id` int(11) NOT NULL COMMENT 'raw material id as foreign key',
  `s_date` datetime NOT NULL COMMENT 'supplies date',
  `s_unitprice` double NOT NULL COMMENT 'supplies unit price',
  `s_quantity` int(11) NOT NULL COMMENT 'quantity of supplies',
  `s_discount` int(11) NOT NULL COMMENT 'discount of supplies',
  PRIMARY KEY (`supplies_id`),
  KEY `fk_s_id` (`s_id`),
  KEY `fk_rmm_id` (`rm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=102 ;

--
-- Dumping data for table `supplies`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `defective_material`
--
ALTER TABLE `defective_material`
  ADD CONSTRAINT `FK_loggedin_id` FOREIGN KEY (`login_id`) REFERENCES `employee` (`login_id`),
  ADD CONSTRAINT `FK_rawmaterial_id` FOREIGN KEY (`rm_id`) REFERENCES `rawmaterial` (`rm_id`);

--
-- Constraints for table `employee`
--
ALTER TABLE `employee`
  ADD CONSTRAINT `fk_et_id` FOREIGN KEY (`et_id`) REFERENCES `employee_type` (`et_id`);

--
-- Constraints for table `factory_material`
--
ALTER TABLE `factory_material`
  ADD CONSTRAINT `FK_logedin_id` FOREIGN KEY (`login_id`) REFERENCES `employee` (`login_id`),
  ADD CONSTRAINT `FK_raw_materials_id` FOREIGN KEY (`rm_id`) REFERENCES `rawmaterial` (`rm_id`);

--
-- Constraints for table `finished_product`
--
ALTER TABLE `finished_product`
  ADD CONSTRAINT `FK_loginnn_id` FOREIGN KEY (`login_id`) REFERENCES `employee` (`login_id`),
  ADD CONSTRAINT `FK_products_id` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`);

--
-- Constraints for table `product`
--
ALTER TABLE `product`
  ADD CONSTRAINT `product_ibfk_1` FOREIGN KEY (`pc_id`) REFERENCES `product_category` (`pc_id`);

--
-- Constraints for table `rawmaterial`
--
ALTER TABLE `rawmaterial`
  ADD CONSTRAINT `fk_rmc_id` FOREIGN KEY (`rmc_id`) REFERENCES `rawmaterial_category` (`rmc_id`);

--
-- Constraints for table `sale_pr`
--
ALTER TABLE `sale_pr`
  ADD CONSTRAINT `FK_customer_id` FOREIGN KEY (`cu_id`) REFERENCES `customer` (`cu_id`),
  ADD CONSTRAINT `fk_login_id` FOREIGN KEY (`login_id`) REFERENCES `employee` (`login_id`),
  ADD CONSTRAINT `fk_pro_id` FOREIGN KEY (`cu_id`) REFERENCES `customer` (`cu_id`),
  ADD CONSTRAINT `fk_purt_id` FOREIGN KEY (`purt_id`) REFERENCES `purchaser_type` (`purt_id`),
  ADD CONSTRAINT `fk_p_id` FOREIGN KEY (`p_id`) REFERENCES `product` (`p_id`),
  ADD CONSTRAINT `fk_st1_id` FOREIGN KEY (`st_id`) REFERENCES `sale_type` (`st_id`),
  ADD CONSTRAINT `fk_st_id` FOREIGN KEY (`st_id`) REFERENCES `sale_type` (`st_id`);

--
-- Constraints for table `sale_rm`
--
ALTER TABLE `sale_rm`
  ADD CONSTRAINT `fk_cus_id` FOREIGN KEY (`cu_id`) REFERENCES `customer` (`cu_id`),
  ADD CONSTRAINT `fk_loginn_id` FOREIGN KEY (`login_id`) REFERENCES `employee` (`login_id`),
  ADD CONSTRAINT `fk_purtt_id` FOREIGN KEY (`purt_id`) REFERENCES `purchaser_type` (`purt_id`),
  ADD CONSTRAINT `fk_rm_id` FOREIGN KEY (`rm_id`) REFERENCES `rawmaterial` (`rm_id`),
  ADD CONSTRAINT `fk_st2_id` FOREIGN KEY (`st_id`) REFERENCES `sale_type` (`st_id`);

--
-- Constraints for table `supplies`
--
ALTER TABLE `supplies`
  ADD CONSTRAINT `fk_rmm_id` FOREIGN KEY (`rm_id`) REFERENCES `rawmaterial` (`rm_id`),
  ADD CONSTRAINT `fk_s_id` FOREIGN KEY (`s_id`) REFERENCES `supplier` (`s_id`);
